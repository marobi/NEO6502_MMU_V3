#pragma once

#include <Arduino.h>

// ============================================================
// usb_storage.h
// NEO MMU - RP2350 USB host storage service
//
// Phase 1 storage layer:
//   - Adafruit TinyUSB native USB host controller
//   - USB MSC attach/remove handling
//   - FAT32 volume detection on USB storage
//
// This module deliberately does not expose monitor debug commands and does
// not implement the 6502 mailbox filesystem API yet.
// ============================================================

void initUSBStorage();
void taskUSBStorage();

bool usb_storage_host_enabled();
bool usb_storage_device_mounted();
bool usb_storage_fat32_mounted();
bool usb_storage_ready();

uint8_t  usb_storage_device_address();
uint8_t  usb_storage_lun();
uint32_t usb_storage_block_count();
uint32_t usb_storage_block_size();
uint32_t usb_storage_partition_lba();
uint32_t usb_storage_partition_sectors();
uint32_t usb_storage_fat32_root_cluster();

// Temporary RP-local status printer used by startup/logging only. This is not
// registered as a monitor command.
void usb_storage_print_summary();
