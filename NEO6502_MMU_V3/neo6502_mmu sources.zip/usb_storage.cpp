#include <Arduino.h>
#include "usb_storage.h"

// ============================================================
// usb_storage.cpp
// NEO MMU - RP2350 USB host storage service
//
// Uses Adafruit TinyUSB host mode. This phase validates the local RP storage
// stack only: USB MSC + FAT32 detection. 6502 mailbox filesystem commands are
// added later after this layer is stable.
// ============================================================

#if defined(USE_TINYUSB_HOST)
  #include "Adafruit_TinyUSB.h"

  static Adafruit_USBH_Host gUSBHost;
#endif

struct USBFAT32Info {
  bool     mounted;
  uint32_t partition_lba;
  uint32_t partition_sectors;
  uint16_t bytes_per_sector;
  uint8_t  sectors_per_cluster;
  uint16_t reserved_sectors;
  uint8_t  fat_count;
  uint32_t sectors_per_fat;
  uint32_t root_cluster;
  uint32_t fat_lba;
  uint32_t data_lba;
};

static bool     gUSBStorageInitialized = false;
static bool     gUSBStorageDeviceMounted = false;
static bool     gUSBStorageMountPending = false;
static uint8_t  gUSBStorageDevAddr = 0;
static uint8_t  gUSBStorageLun = 0;
static uint32_t gUSBStorageBlockCount = 0;
static uint32_t gUSBStorageBlockSize = 0;
static USBFAT32Info gFAT32 = {};

// Keep sector buffer static and aligned. TinyUSB host transfers can be
// DMA/cache sensitive depending on target/core configuration.
static uint8_t gSector[512] __attribute__((aligned(4)));
static volatile bool gReadDone = false;
static volatile bool gReadOK = false;

#if defined(USE_TINYUSB_HOST)
static bool usb_storage_msc_read_complete(uint8_t dev_addr, const tuh_msc_complete_data_t* cb_data);
#endif

static uint16_t le16(const uint8_t* p) {
  return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static uint32_t le32(const uint8_t* p) {
  return (uint32_t)p[0] |
         ((uint32_t)p[1] << 8) |
         ((uint32_t)p[2] << 16) |
         ((uint32_t)p[3] << 24);
}

static void clear_fat32_state() {
  memset(&gFAT32, 0, sizeof(gFAT32));
}

void initUSBStorage() {
  if (gUSBStorageInitialized)
    return;

#if defined(USE_TINYUSB_HOST)
  Serial1.println("*I: USB host storage: init native host controller");
  gUSBHost.begin(0);
#else
  Serial1.println("*E: USB host storage: USE_TINYUSB_HOST is not enabled");
#endif

  gUSBStorageInitialized = true;
}

/// <summary>
/// this function is called repeatedly in the main loop to handle USB host tasks and FAT32 detection/mounting. 
/// It checks for new USB storage devices, handles their attachment/detachment, 
/// and attempts to mount FAT32 volumes when a device is detected. 
/// The function ensures that the USB host stack is initialized and processes any pending mount requests.
/// </summary>
void taskUSBStorage() {
#if defined(USE_TINYUSB_HOST)
  if (!gUSBStorageInitialized)
    initUSBStorage();

  gUSBHost.task();

  if (gUSBStorageMountPending) {
    gUSBStorageMountPending = false;

    // FAT32 detection is intentionally performed outside tuh_msc_mount_cb().
    // The TinyUSB callback only records device presence; normal task context
    // does the sector reads and filesystem parsing.
    if (gUSBStorageDeviceMounted && !gFAT32.mounted) {
      Serial1.println("*I: USB storage: probing FAT32 volume");

      // Mount attempt is synchronous but bounded. Later mailbox FS calls can
      // be made asynchronous if real USB latency requires it.
      extern bool usb_storage_mount_fat32();
      usb_storage_mount_fat32();
    }
  }
#endif
}

bool usb_storage_host_enabled() {
#if defined(USE_TINYUSB_HOST)
  return true;
#else
  return false;
#endif
}

bool usb_storage_device_mounted() {
  return gUSBStorageDeviceMounted;
}

bool usb_storage_fat32_mounted() {
  return gFAT32.mounted;
}

bool usb_storage_ready() {
  return gUSBStorageDeviceMounted && gFAT32.mounted;
}

uint8_t usb_storage_device_address() { return gUSBStorageDevAddr; }
uint8_t usb_storage_lun() { return gUSBStorageLun; }
uint32_t usb_storage_block_count() { return gUSBStorageBlockCount; }
uint32_t usb_storage_block_size() { return gUSBStorageBlockSize; }
uint32_t usb_storage_partition_lba() { return gFAT32.partition_lba; }
uint32_t usb_storage_partition_sectors() { return gFAT32.partition_sectors; }
uint32_t usb_storage_fat32_root_cluster() { return gFAT32.root_cluster; }

static bool usb_storage_read_sector(uint32_t lba, uint8_t* buffer, uint32_t timeout_ms) {
#if defined(USE_TINYUSB_HOST)
  if (!gUSBStorageInitialized)
    initUSBStorage();

  if (!gUSBStorageDeviceMounted) {
    Serial1.println("*E: USB storage: no MSC device mounted");
    return false;
  }

  if (gUSBStorageBlockSize != 512) {
    Serial1.printf("*E: USB storage: unsupported block size %lu\n", (unsigned long)gUSBStorageBlockSize);
    return false;
  }

  if (lba >= gUSBStorageBlockCount) {
    Serial1.printf("*E: USB storage: LBA %lu out of range\n", (unsigned long)lba);
    return false;
  }

  if (!tuh_msc_ready(gUSBStorageDevAddr)) {
    Serial1.println("*E: USB storage: MSC device busy/not ready");
    return false;
  }

  gReadDone = false;
  gReadOK = false;
  memset(buffer, 0, 512);

  if (!tuh_msc_read10(gUSBStorageDevAddr,
                      gUSBStorageLun,
                      buffer,
                      lba,
                      1,
                      usb_storage_msc_read_complete,
                      (uintptr_t)lba)) {
    Serial1.println("*E: USB storage: failed to queue READ10");
    return false;
  }

  uint32_t const start_ms = millis();
  while (!gReadDone) {
    gUSBHost.task();
    if ((uint32_t)(millis() - start_ms) >= timeout_ms) {
      Serial1.println("*E: USB storage: READ10 timeout");
      return false;
    }
    delay(1);
  }

  if (!gReadOK) {
    Serial1.println("*E: USB storage: READ10 failed");
    return false;
  }

  return true;
#else
  (void)lba;
  (void)buffer;
  (void)timeout_ms;
  Serial1.println("*E: USB storage: USE_TINYUSB_HOST is not enabled");
  return false;
#endif
}

static bool looks_like_fat32_boot_sector(const uint8_t* bs) {
  if (bs[510] != 0x55 || bs[511] != 0xAA)
    return false;

  // FAT32 usually has "FAT32   " at offset 0x52. Do not rely only on this,
  // but reject obvious non-FAT32 sectors.
  if (memcmp(&bs[0x52], "FAT32", 5) != 0)
    return false;

  uint16_t const bytes_per_sector = le16(&bs[0x0B]);
  uint8_t const sectors_per_cluster = bs[0x0D];
  uint16_t const reserved = le16(&bs[0x0E]);
  uint8_t const fats = bs[0x10];
  uint16_t const root_entries = le16(&bs[0x11]);
  uint16_t const total16 = le16(&bs[0x13]);
  uint32_t const total32 = le32(&bs[0x20]);
  uint16_t const fat16 = le16(&bs[0x16]);
  uint32_t const fat32 = le32(&bs[0x24]);
  uint32_t const root_cluster = le32(&bs[0x2C]);

  if (bytes_per_sector != 512)
    return false;
  if (sectors_per_cluster == 0)
    return false;
  if (reserved == 0)
    return false;
  if (fats == 0)
    return false;
  if (root_entries != 0)
    return false;
  if (total16 != 0 || total32 == 0)
    return false;
  if (fat16 != 0 || fat32 == 0)
    return false;
  if (root_cluster < 2)
    return false;

  return true;
}

static bool parse_fat32_boot_sector(uint32_t partition_lba, uint32_t partition_sectors, const uint8_t* bs) {
  if (!looks_like_fat32_boot_sector(bs))
    return false;

  gFAT32.partition_lba = partition_lba;
  gFAT32.partition_sectors = partition_sectors ? partition_sectors : le32(&bs[0x20]);
  gFAT32.bytes_per_sector = le16(&bs[0x0B]);
  gFAT32.sectors_per_cluster = bs[0x0D];
  gFAT32.reserved_sectors = le16(&bs[0x0E]);
  gFAT32.fat_count = bs[0x10];
  gFAT32.sectors_per_fat = le32(&bs[0x24]);
  gFAT32.root_cluster = le32(&bs[0x2C]);
  gFAT32.fat_lba = gFAT32.partition_lba + gFAT32.reserved_sectors;
  gFAT32.data_lba = gFAT32.fat_lba + ((uint32_t)gFAT32.fat_count * gFAT32.sectors_per_fat);
  gFAT32.mounted = true;

  Serial1.println("*I: USB FAT32 mounted");
  Serial1.printf("    partition LBA       : %lu\n", (unsigned long)gFAT32.partition_lba);
  Serial1.printf("    partition sectors   : %lu\n", (unsigned long)gFAT32.partition_sectors);
  Serial1.printf("    sectors/cluster     : %u\n", gFAT32.sectors_per_cluster);
  Serial1.printf("    FAT LBA             : %lu\n", (unsigned long)gFAT32.fat_lba);
  Serial1.printf("    data LBA            : %lu\n", (unsigned long)gFAT32.data_lba);
  Serial1.printf("    root cluster        : %lu\n", (unsigned long)gFAT32.root_cluster);
  return true;
}

bool usb_storage_mount_fat32() {
  clear_fat32_state();

  if (!gUSBStorageDeviceMounted) {
    Serial1.println("*E: USB FAT32: no MSC device mounted");
    return false;
  }

  if (gUSBStorageBlockSize != 512) {
    Serial1.printf("*E: USB FAT32: unsupported block size %lu\n", (unsigned long)gUSBStorageBlockSize);
    return false;
  }

  if (!usb_storage_read_sector(0, gSector, 2000))
    return false;

  if (gSector[510] != 0x55 || gSector[511] != 0xAA) {
    Serial1.println("*E: USB FAT32: LBA0 has no 55 AA signature");
    return false;
  }

  // Case 1: superfloppy FAT32, boot sector directly at LBA 0.
  if (parse_fat32_boot_sector(0, gUSBStorageBlockCount, gSector))
    return true;

  // Case 2: MBR partitioned FAT32. GPT/exFAT/NTFS are deliberately rejected
  // for the first NEOX USB-storage filesystem milestone.
  for (uint8_t i = 0; i < 4; i++) {
    uint16_t const off = 0x01BE + ((uint16_t)i * 16);
    uint8_t const type = gSector[off + 4];
    uint32_t const start_lba = le32(&gSector[off + 8]);
    uint32_t const sectors = le32(&gSector[off + 12]);

    if ((type == 0x0B || type == 0x0C) && start_lba != 0 && sectors != 0) {
      if (!usb_storage_read_sector(start_lba, gSector, 2000))
        return false;

      if (parse_fat32_boot_sector(start_lba, sectors, gSector))
        return true;

      Serial1.println("*E: USB FAT32: partition type is FAT32 but boot sector parse failed");
      return false;
    }

    if (type == 0xEE) {
      Serial1.println("*E: USB FAT32: GPT protective MBR found; reformat USB stick as MBR/FAT32");
      return false;
    }
  }

  Serial1.println("*E: USB FAT32: no FAT32 MBR partition or superfloppy FAT32 boot sector found");
  return false;
}

void usb_storage_print_summary() {
  Serial1.println("USB storage summary");
  Serial1.print("  host        : ");
  Serial1.println(usb_storage_host_enabled() ? "enabled" : "disabled");
  Serial1.print("  initialized : ");
  Serial1.println(gUSBStorageInitialized ? "yes" : "no");
  Serial1.print("  device      : ");
  Serial1.println(gUSBStorageDeviceMounted ? "mounted" : "not mounted");
  Serial1.print("  FAT32       : ");
  Serial1.println(gFAT32.mounted ? "mounted" : "not mounted");
  if (gUSBStorageBlockSize && gUSBStorageBlockCount) {
    uint64_t const bytes = (uint64_t)gUSBStorageBlockSize * (uint64_t)gUSBStorageBlockCount;
    Serial1.printf("  capacity    : %lu MiB\n", (unsigned long)(bytes / (1024ULL * 1024ULL)));
  }
  if (gFAT32.mounted) {
    Serial1.printf("  part LBA    : %lu\n", (unsigned long)gFAT32.partition_lba);
    Serial1.printf("  root clus   : %lu\n", (unsigned long)gFAT32.root_cluster);
  }
}

#if defined(USE_TINYUSB_HOST)
static bool usb_storage_msc_read_complete(uint8_t dev_addr, const tuh_msc_complete_data_t* cb_data) {
  (void)dev_addr;

  gReadOK = (cb_data != nullptr) &&
            (cb_data->csw != nullptr) &&
            (cb_data->csw->status == 0);
  gReadDone = true;
  return true;
}

void tuh_msc_mount_cb(uint8_t dev_addr) {
  uint8_t const lun = 0;

  gUSBStorageDevAddr = dev_addr;
  gUSBStorageLun = lun;
  gUSBStorageBlockCount = tuh_msc_get_block_count(dev_addr, lun);
  gUSBStorageBlockSize = tuh_msc_get_block_size(dev_addr, lun);
  gUSBStorageDeviceMounted = true;
  gUSBStorageMountPending = true;
  clear_fat32_state();

  Serial1.printf("*I: USB MSC mounted: dev=%u lun=%u\n", dev_addr, lun);
}

void tuh_msc_umount_cb(uint8_t dev_addr) {
  if (dev_addr == gUSBStorageDevAddr) {
    gUSBStorageDeviceMounted = false;
    gUSBStorageMountPending = false;
    gUSBStorageDevAddr = 0;
    gUSBStorageLun = 0;
    gUSBStorageBlockCount = 0;
    gUSBStorageBlockSize = 0;
    clear_fat32_state();
  }

  Serial1.printf("*I: USB MSC removed: dev=%u\n", dev_addr);
}
#endif
